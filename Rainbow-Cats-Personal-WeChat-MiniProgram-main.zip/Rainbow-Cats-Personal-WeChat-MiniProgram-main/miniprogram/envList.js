const envList = [{"envId":"这里写自己的envId","alias":"cloud1"}]
const isMac = false
module.exports = {
    envList,
    isMac
}